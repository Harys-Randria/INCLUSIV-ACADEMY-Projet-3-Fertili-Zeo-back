package com.fertilizeo.controller;

public class LoginHistoryController {
}
