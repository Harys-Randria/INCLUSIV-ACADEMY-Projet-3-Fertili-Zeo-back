package com.fertilizeo.entity;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@DiscriminatorValue("4")
@Entity
public class Producteur extends Compte {



}

