package com.fertilizeo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FertilizeoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FertilizeoApplication.class, args);
	}

}
